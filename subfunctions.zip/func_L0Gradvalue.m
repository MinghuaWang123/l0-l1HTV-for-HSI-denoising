function[L0TV] = func_L0Gradvalue(Du)

Du(end,:,:,1) = 0;
Du(:,end,:,2) = 0;
L0TV = nnz(round(sum(sum(abs(Du),4),3)));
