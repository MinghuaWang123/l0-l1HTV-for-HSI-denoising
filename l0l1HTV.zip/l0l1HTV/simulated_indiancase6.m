%%L0-L1HTV

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Minghua Wang (minghuawang1993@163.com)
% Last version: May 7, 2020
% Article: l0-l1 Hybrid Total Variation Regularization and Its Applications on Hyperspectral Image Mixed Noise Removal and Compressed Sensing
% https://ieeexplore.ieee.org/document/9354456
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;clc;close all;

load Indiancom_case6.mat;

%% Set parameters and call algorithm

[m,n,dim]=size(T);

%% SSL0TV


lambda= 0.08; mu= 0.1 ; nu= 0.3  ; iter=40;%  42.85 dB SSIM 0.9901


imsize = size(T);
N = imsize(1)*(imsize(2)); % number of pixels

%%%%%%%%%%%%%%%%%%%%% User Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%
alpha = round(0.13*N); % L0 gradient of output image pavia 
gamma =1/nu; % stepsize of ADMM  
epsilon = 0.0002*N; % stopping criterion 

 for i =1:length(lambda)
     tic;
[ denoised]=funSSTV_L0SSTV(T,C,iter,lambda(i),alpha,nu,mu,gamma);%  
toc;

IndiannL0L1TVresult=calcDenoiseResult( C,T,denoised,'Indian L0L1HTV',false );
 end
  msacase1=MSA(C,denoised);
ergascase1 = ErrRelGlobAdimSyn(C,denoised);

A=reshape(C,m*n,dim);
B=reshape(denoised,m*n,dim);
msad = mSAD(A,B);
 figure,imshow(C(:,:,12),[]); 
  figure,imshow(T(:,:,12),[]); 
 figure,imshow(denoised(:,:,12),[]); 

